def original_addr(csock):
    return csock.getsockname()
